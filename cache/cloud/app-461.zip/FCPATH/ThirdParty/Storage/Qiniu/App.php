<?php

return [

    'id' => 5,
    'name' => '七牛云',

];