<?php

return [

    'id' => 2,
    'name' => '阿里云',

];