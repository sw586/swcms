<?php

return [

    'id' => 3,
    'name' => '腾讯云',

];